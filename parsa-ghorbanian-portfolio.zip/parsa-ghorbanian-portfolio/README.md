# Parsa Ghorbanian — Portfolio

A six-section, responsive personal portfolio built with semantic HTML, CSS and vanilla JavaScript.

## Run locally
Open `index.html` in a browser. No build step or package manager is required.

## Included
- Six full-screen-inspired portfolio sections
- Responsive desktop and mobile navigation
- Scroll reveal, progress indicator and restrained parallax
- Reduced-motion support
- Space Grotesk + IBM Plex Mono typography
- Project links for Parnian AI, Radio Sam and Parnian Front-end School

## Personalization notes
The hero portrait uses a publicly indexed image from a Node.js seminar post. Confirm the photo before publishing the site publicly. Replace the image URL in `index.html` if you prefer another portrait.
Update project URLs, social links and copy as needed.

## Files
- `index.html`
- `styles.css`
- `script.js`
